
public class Skeleton0 {
	public Skeleton0() {
		//DerbyConnection.StartServer();
		LoginO.getInstance().setVisible(true);
			}

	public static void main(String[] args) {
		new Skeleton0();
	}

}
